package com.palul.hdfs;

import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Reducer;
import org.apache.hadoop.yarn.webapp.hamlet.Hamlet;

import java.io.IOException;

/**
 * 选择继承得Reducer类
 * Reducer有4个泛型参数
 * 第一对 kv: 要于Mapper类 得输出一致
 * 第二对 kv: 自己设计决定输出得结果是什么类型
 */
public class WordCountReducer extends Reducer<Text, IntWritable,Text,IntWritable> {
    // 1.重写 reduce方法

    /**
     *
     * @param key 为 map输出方法得key 表示 word 一个单词
     * @param values  是一组key相同得key value组成得集合
     *   假设 map方法输出： hello 1 ;  hello  1 ; hello 1
     *      reduce得key和value是什么?
     *       key: hello
     *       values: <1,1,1>
     *       reduce 方法在什么时候被调用？
     *        在一组key  相同得kv  中得value组成集合然后调用.
     *          hello  1;hello  1; hadoop 1; haddop 1 ;reduce  1; reduce 1;
     *               在调用是第一次 key:hello  value:<1,1,>
     *                第二次  key: hadoop  value:<1,1>
     * @param context
     * @throws IOException
     * @throws InterruptedException
     */
    IntWritable total = new IntWritable();
    @Override
    protected void reduce(Text key, Iterable<IntWritable> values, Context context) throws IOException, InterruptedException {
        //2.遍历key对应得values 并累加结果
        int sum =0;
        for(IntWritable iw: values){
            int i = iw.get();
            sum += i;
        }
        //3. 输出当前key对应得单词
        total.set(sum);
        context.write(key,total);
    }
}
