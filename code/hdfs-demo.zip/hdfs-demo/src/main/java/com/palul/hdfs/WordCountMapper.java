package com.palul.hdfs;

import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Mapper;

import java.io.IOException;

//1. 继承Mapper类

/**
 * 需求： 统计单词出现次数
 * Mapper类得泛行 参数4个
 * 第一对 kv : map 输入参数类型
 * 第二对 kb: map 输出类型参数
 * LongWritable,Text ---》文本偏移量  ，一行文本内容
 * Text, IntWritable ---->  单词  ， 1
 */
public class WordCountMapper extends Mapper<LongWritable,Text,Text, IntWritable> {
    // 提升为全局变量，避免每次执行map方法
    Text word = new Text();
    IntWritable one = new IntWritable(1);

    /**
     *
     * @param key  文本偏移量
     * @param value   一行文本内容
     * @param context
     * @throws IOException
     * @throws InterruptedException
     */

    // 重写Mapper类得方法
    @Override
    protected void map(LongWritable key, Text value, Context context) throws IOException, InterruptedException {

        /**
         * 1.接受 到文本内容转为String 类型
         * 2. 按照空格进行切分
         * 3. 输出<单词,1>
         *
         */
        //接受 到文本内容转为String 类型
        String str = value.toString();
        // 按照空格进行切分
        String[] words = str.split(" ");

        // 遍历数组
        for (String s : words) {
            word.set(s); //hadoop 对String 进行了序列化封装
            // 输出<单词,1>
            context.write(word,one);
        }


    }


}
