package com.palul.hdfs;

import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.io.IntWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Job;
import org.apache.hadoop.mapreduce.lib.input.FileInputFormat;
import org.apache.hadoop.mapreduce.lib.output.FileOutputFormat;

import java.io.IOException;

/**
 * 封装任务并提交运行
 */
public class WordCountDriver {

    public static void main(String[] args) throws IOException, ClassNotFoundException, InterruptedException {
        /**
         * 1. 获取配置文件对象，获取job对象实例
         * 2. 指定程序jar的本地路径
         * 3. 指定Mapper/Reducer类 4. 指定Mapper输出的kv数据类型
         * 5. 指定最终输出的kv数据类型
         * 6. 指定job处理的原始数据路径
         * 7. 指定job输出结果路径
         * 8. 提交作业
          */

        // 获取配置文件对象，获取job对象实例
        Configuration conf = new Configuration();
        Job job = Job.getInstance(conf, "WordCount");
        // 指定程序jar的本地路径
        job.setJarByClass(WordCountDriver.class);
        // 指定Mapper/Reducer类
        job.setMapperClass(WordCountMapper.class);
        // 指定Mapper输出的kv数据类型
        job.setReducerClass(WordCountReducer.class);

        // 指定Mapper最终输出的kv数据类型
        job.setMapOutputKeyClass(Text.class);
        job.setMapOutputValueClass(IntWritable.class);
        // /Users/paul/go/sunshineboy.txt   /Users/paul/mapreduce
        // 指定最终输出的kv数据类型
        job.setOutputKeyClass(Text.class);
        job.setOutputValueClass(IntWritable.class);
        // 指定job处理得原始数据路径
        FileInputFormat.setInputPaths(job,new Path(args[0]));
        //指定job输出结果路径
        FileOutputFormat.setOutputPath(job,new Path(args[1]));
        // 提交作业
        boolean b = job.waitForCompletion(true);
        // jvm 正常退出为0 ,非0 为错误退出
        System.exit(b?0:1);
    }
}
