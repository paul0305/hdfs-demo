package com.paul.speak;

import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Mapper;

import java.io.IOException;

/**
 * 第一对 kv : map输入kv 类型 k -->文本偏移量 v -->一行文本
 * 第二对 kv : map输出kv  k--> map输出key类型  v: map 输出得 value 类型
 */
public class SpeakMapper extends Mapper<LongWritable,Text,Text,SpeakBean> {
    //1.转化text 为string
    //2. 按照制表符分割

    Text deviceText = new Text();
    @Override
    protected void map(LongWritable key, Text value, Context context) throws IOException, InterruptedException {
        String line = value.toString();
        String[] fields = line.split("\t");
         //自有内容时长
        String selfDuration = fields[fields.length - 3];
        //第三方 内容时长
        String thirdDuration = fields[fields.length-2];
        //设备id
        String deviceId = fields[1];
        SpeakBean speakBean = new SpeakBean(Long.parseLong(selfDuration), Long.parseLong(thirdDuration), deviceId);
        //输出
        deviceText.set(deviceId);
        context.write(deviceText,speakBean);


    }
}
