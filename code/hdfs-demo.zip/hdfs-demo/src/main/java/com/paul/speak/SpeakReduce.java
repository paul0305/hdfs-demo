package com.paul.speak;

import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Reducer;

import java.io.IOException;

/**
 * 继承Reducer接口
 */
public class SpeakReduce extends Reducer<Text,SpeakBean,Text,SpeakBean> {
    /**
     *
     * @param key map输出得key
     * @param values  map输出k-v 对中相同key 得value 组成得集合
     * @param context
     * @throws IOException
     * @throws InterruptedException
     */
    @Override
    protected void reduce(Text key, Iterable<SpeakBean> values, Context context) throws IOException, InterruptedException {
        //定义时长累加得初始值
        Long self_duration = 0L;
        Long third_part_duration = 0L;
        // 遍历迭代器，累加时长
        for (SpeakBean bean : values) {
            Long selfDuration = bean.getSelfDuration();
            Long thirdPartDuration = bean.getThirdPartDuration();
            self_duration += selfDuration;
            third_part_duration += thirdPartDuration;
        }
        //输出结果，结果封装一个bean
        SpeakBean speakBean = new SpeakBean(self_duration, third_part_duration, key.toString());
        context.write(key,speakBean);
    }
}
