package com.palul.hdfs;

public class HdfsClient {


    public  void  testMkdirs(){


    }
}
