package com.com.paul;

import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Mapper;

import java.io.IOException;

/**
 * 利用MR的sort能力 ，
 * k1,v1  (行偏移量,行值)
 * k2,v2  (行值，1)
 */
public class SortMapper extends Mapper<LongWritable, Text,LongWritable,LongWritable> {
    @Override
    protected void map(LongWritable key, Text value, Context context) throws IOException, InterruptedException {
        String line = value.toString();
        context.write(new LongWritable(Integer.parseInt(line)),new LongWritable(1));

    }
}
