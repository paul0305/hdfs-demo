package com.paul.hdfs;

import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.fs.*;
import org.apache.hadoop.fs.permission.FsPermission;
import org.apache.hadoop.io.IOUtils;
import org.junit.Test;

import java.io.File;
import java.io.FileInputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.net.URI;
import java.net.URISyntaxException;
import java.security.PublicKey;

public class HdfsClient {
    /**
     * 使用java 客户端 创建目录
     */
    @Test
    public  void  testMkdirs() throws URISyntaxException, IOException, InterruptedException {
        //0 . 创建配置
        Configuration configuration = new Configuration();
//        configuration.set("fs.defaultFS","hdfs://linux107:9000");
        //1. 获取文件系统
        /**
         * @param URI  hdfs : 通信协议 //主机名或者ip:端口  9000是默认api端口
         * @param configuraion   可以配置 连接信息
         * @param  user  用户 root
         */
        FileSystem fileSystem = FileSystem.get(new URI("hdfs://linux107:9000"), configuration, "root");
        //配置在集群上运行 参数1 uri  ,参数2 configuration ,参数3  user 用户

        //2. 创建目录 Path("字符串路径")
        boolean mkdirs = fileSystem.mkdirs(new Path("/stronger"));
        if(mkdirs){
            System.out.println("创建目录成功!");
        }

        //3 关闭资源
        fileSystem.close();
    }

    /**
     * 测试上传文件
     */
    @Test
    public  void  testCopyFromLocalFile() throws URISyntaxException, IOException, InterruptedException {
        //1.获取文件系统
        Configuration configuration = new Configuration();
        // 设置分片副本数量2
        configuration.set("dfs.replication","2");
        // linux107 主机名要在 vim /etc/hosts中配置 192.168.0.107  linux107
        FileSystem fileSystem = FileSystem.get(new URI("hdfs://linux107:9000"), configuration, "root");
        //2. 上传文件
        fileSystem.copyFromLocalFile(new Path("/Users/paul/go/sunshineboy.txt"),new Path("/sunshineboy.txt"));
        //3. 关闭资源
        fileSystem.close();

        System.out.println("上传结束");
    }

    /**
     * 测试下载文件
     */
    @Test
    public  void  testCopyToLocalFile() throws URISyntaxException, IOException, InterruptedException {
        //1.获取文件系统
        Configuration configuration = new Configuration();
        // 设置分片副本数量2
        configuration.set("dfs.replication","2");
        // linux107 主机名要在 vim /etc/hosts中配置 192.168.0.107  linux107
        FileSystem fileSystem = FileSystem.get(new URI("hdfs://linux107:9000"), configuration, "root");
        //2. 下载文件
        /**
         * boolean delSrc 是否将原来得文件删除
         * Path src  指定要下载得文件路径
         * Path dst  指定将下载文件保存得路径
         * boolean  useRawLocationFileSystem 是否开启文件校验
         */
        fileSystem.copyToLocalFile(false,new Path("/sunshineboy.txt"),new Path("/Users/paul/go/sunshineboy_copy.txt"),true);
        //3. 关闭资源
        fileSystem.close();

        System.out.println("end");
    }

    /**
     * 删除文件或文件夹
     * @throws URISyntaxException
     * @throws IOException
     * @throws InterruptedException
     */
    @Test
    public  void testDeletFile() throws URISyntaxException, IOException, InterruptedException {
        // 创建FileSystem
        Configuration configuration = new Configuration();
        FileSystem fileSystem = FileSystem.get(new URI("hdfs://linux107:9000"), configuration, "root");
        // 参数1 path 路径 参数2： true  是否递归得删除文件
        boolean delete = fileSystem.delete(new Path("/test"), true);
        //关闭资源
        fileSystem.close();
    }

    /**
     * 遍历hdfs 的根目录，得到文件以及文件夹得信息
     * 名称： 权限： 长度等
     */
    @Test
    public  void listFileInfo() throws URISyntaxException, IOException, InterruptedException {

        Configuration configuration = new Configuration();
        FileSystem fileSystem = FileSystem.get(new URI("hdfs://linux107:9000"), configuration, "root");
        // 参数1 path 路径 参数2： true  是否递归文件,得到一个迭代器 装有指定目录下文件信息
        RemoteIterator<LocatedFileStatus> remoteIterator = fileSystem.listFiles(new Path("/"), true);
        //遍历迭代器
        while (remoteIterator.hasNext()){
            LocatedFileStatus locatedFileStatus = remoteIterator.next();
            // 文件名称
            String fileName = locatedFileStatus.getPath().getName();
            // 文件长度
            long len = locatedFileStatus.getLen();
            //权限
            FsPermission permission = locatedFileStatus.getPermission();
            //分组
            String group = locatedFileStatus.getGroup();
            //所属于用户
            String owner = locatedFileStatus.getOwner();
            System.out.println("文件名称："+fileName+"  长度:"+len+"   权限："+
                    permission+"  分组："+group+"   所属于用户:"+owner);
            //块信息
            BlockLocation[] blockLocations = locatedFileStatus.getBlockLocations();
            for(BlockLocation blockLocation:blockLocations){
                String[] hosts = blockLocation.getHosts(); //主机信息
                for(String host:hosts){
                    System.out.println("块所在得主机为："+host);
                }
            }

            System.out.println("------------");


        }
    }

    /**
     * 文件和文件夹得判断
     */
    @Test
    public void  isFileTest() throws URISyntaxException, IOException, InterruptedException {
        Configuration configuration = new Configuration();
        FileSystem fileSystem = FileSystem.get(new URI("hdfs://linux107:9000"), configuration, "root");
        RemoteIterator<LocatedFileStatus> listFiles = fileSystem.listFiles(new Path("/"), true);
        while (listFiles.hasNext()){
            LocatedFileStatus fileStatus = listFiles.next();
            if(fileStatus.isDirectory()){//判断是文件夹
                System.out.println(fileStatus.getPath().getName()+"--是文件夹");
            }else {
                System.out.println(fileStatus.getPath().getName()+"--是文件");
            }

        }

    }

    /**
     * 使用io 操作hdfs
     * 上传文件：准备输入流读取本地文件，使用hdfs得输出流写数据到hdfs
     */
    @Test
    public  void FileIoOperation() throws URISyntaxException, IOException, InterruptedException {
       Configuration configuration = new Configuration();
        FileSystem fileSystem = FileSystem.get(new URI("hdfs://linux107:9000"), configuration, "root");
        //本地文件得输入刘
        FileInputStream fileInputStream = new FileInputStream(new File("/Users/paul/go/testhadoopio.txt"));
        //2. 准备写数据到hdfs  输出流
        FSDataOutputStream fsDataOutputStream = fileSystem.create(new Path("/go/testhadoopio.txt"), true);
        //3. 输入流数据拷贝到 输出流
        /**
         * 参数1 输入流
         * 参数2 输出流
         * 参数3 每次传送大小 4096字节
         * 参数4 close 使用完毕关闭流
         */
        // IOUtils.copyBytes(fileInputStream,fsDataOutputStream,4096,true);
         IOUtils.copyBytes(fileInputStream,fsDataOutputStream,4096,true);
        //可以再次关闭流
    }

    /**
     * 测试io流下载
     * @throws URISyntaxException
     * @throws IOException
     * @throws InterruptedException
     */
    @Test
    public  void FileIoDownloadOperation() throws URISyntaxException, IOException, InterruptedException {
        Configuration configuration = new Configuration();
        FileSystem fileSystem = FileSystem.get(new URI("hdfs://linux107:9000"), configuration, "root");
      //1. 读取hdfs得输入流
        FSDataInputStream fsDataInputStream = fileSystem.open(new Path("/go/testhadoopio.txt"));
      // 2. 本地文件得输出流
        FileOutputStream fileOutputStream = new FileOutputStream(new File("/Users/paul/go/jokeGo.txt"));
        //3.流拷贝
        IOUtils.copyBytes(fsDataInputStream,fileOutputStream,4096,true);
    }

    /**
     * 测试定位读取
     * seek 定位读取hdfs文件 使用流读取go/testhadoopio.txt
     * 并把内容输出两次，本质是读取一遍之后，在seek到从再次读取
     */

    @Test
    public  void  seekReadFile() throws URISyntaxException, IOException, InterruptedException {
        Configuration configuration = new Configuration();
        FileSystem fileSystem = FileSystem.get(new URI("hdfs://linux107:9000"), configuration, "root");
        //1. 读取hdfs得输入流
        FSDataInputStream fsDataInputStream = fileSystem.open(new Path("/go/testhadoopio.txt"));
        //2. 控制台输出 实现流拷贝
        //IOUtils.copyBytes(fsDataInputStream,System.out,configuration);
        //不要关闭流
        IOUtils.copyBytes(fsDataInputStream,System.out,4096,false);
        //4.再次读取
        fsDataInputStream.seek(0);  //偏移量定位到0 从文件头开始读取
        // 读取文件，并且关闭流
        IOUtils.copyBytes(fsDataInputStream,System.out,4096,false);
        //5.关闭输入流
        IOUtils.closeStream(fsDataInputStream);
    }
}
