package com.com.paul;

import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.mapreduce.Reducer;

import java.io.IOException;

/**
 * 接受来在mapper段的数据， <k2,[v2,v2,v2]>
 *     此时的数据已经按照key进行了排序
 */
public class SortReducer extends Reducer<LongWritable,LongWritable,LongWritable,LongWritable> {
    private  static LongWritable linesum = new LongWritable(1);


    @Override
    protected void reduce(LongWritable key, Iterable<LongWritable> values, Context context) throws IOException, InterruptedException {
        for(LongWritable v :values){
            context.write(linesum,key);
            linesum = new LongWritable(linesum.get()+1);
        }
    }
}
