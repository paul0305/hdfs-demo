package com.paul.speak;

import org.apache.hadoop.io.Writable;

import java.io.DataInput;
import java.io.DataOutput;
import java.io.IOException;

/**
 * 这个类型 map输出kv 中value类型，需要实现writable序列化接口
 */
public class SpeakBean implements Writable {
    // 定义属性
    private  Long selfDuration; //自有内容时长
    private  Long thirdPartDuration;// 第三方内容时长
    private  String deviceId;  // 设备id
    private  Long sumDuration;  //总时长

    public Long getSelfDuration() {
        return selfDuration;
    }

    public void setSelfDuration(Long selfDuration) {
        this.selfDuration = selfDuration;
    }

    public Long getThirdPartDuration() {
        return thirdPartDuration;
    }

    public void setThirdPartDuration(Long thirdPartDuration) {
        this.thirdPartDuration = thirdPartDuration;
    }

    public String getDeviceId() {
        return deviceId;
    }

    public void setDeviceId(String deviceId) {
        this.deviceId = deviceId;
    }

    public Long getSumDuration() {
        return sumDuration;
    }

    public void setSumDuration(Long sumDuration) {
        this.sumDuration = sumDuration;
    }

    @Override
    public String toString() {
        return "SpeakBean{" +
                "selfDuration=" + selfDuration +
                ", thirdPartDuration=" + thirdPartDuration +
                ", deviceId='" + deviceId + '\'' +
                ", sumDuration=" + sumDuration +
                '}';
    }

    //准备个空参数构造


    public SpeakBean() {

    }

    public SpeakBean(Long selfDuration, Long thirdPartDuration, String deviceId) {
        this.selfDuration = selfDuration;
        this.thirdPartDuration = thirdPartDuration;
        this.deviceId = deviceId;
        this.sumDuration = this.selfDuration + this.thirdPartDuration;
    }

    //1. 实现序列化方法  被内容输出到网络
    @Override
    public void write(DataOutput out) throws IOException {
        out.writeLong(selfDuration);
        out.writeLong(thirdPartDuration);
        out.writeUTF(deviceId);
        out.writeLong(sumDuration);
    }

    /**
     * 2. 实现反序列化方法
     * @param in
     * @throws IOException
     */
    @Override
    public void readFields(DataInput in) throws IOException {
        //注意 ：反序列化得时候 ，数序一定要与序列化时候得顺序一致
        this.selfDuration = in.readLong();// 读取自有时长
        this.thirdPartDuration = in.readLong();
        this.deviceId = in.readUTF();
        this.sumDuration = in.readLong();
    }
}
